package org.firedetection.dao;

public interface DbMapper {
	 public String getDual() throws Exception;
}
