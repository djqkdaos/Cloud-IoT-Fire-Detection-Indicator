package org.firedetection.dao;

import java.util.List;

import org.firedetection.vo.TestVo;

public interface TestMapper {
	String getTestList() throws Exception;
}
