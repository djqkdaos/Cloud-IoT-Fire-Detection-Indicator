package org.firedetection.controller;

import java.util.List;

import org.firedetection.service.TestService;
import org.firedetection.vo.TestVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

//@RestController
public class TestController {
	/*@Autowired
    TestService testService;
     
    @RequestMapping("/")
    public @ResponseBody String root_test() throws Exception{  
        return "Hello World";
    }
 
    @RequestMapping("/test")
    public @ResponseBody String now() throws Exception{
    	//List<TestVo> List = testService.getTestList();
    	
        return testService.getTestList();
    }
*/

}
