package org.firedetection.biz.board.dao;

public interface ReviewBoardDAO {

}
