package org.firedetection.biz.board.vo;

public class CounselBoardVO {

}
