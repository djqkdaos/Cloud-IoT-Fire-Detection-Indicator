package org.firedetection.biz.users.vo;

public class IntroduceVO {

}
