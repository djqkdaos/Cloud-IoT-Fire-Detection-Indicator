package org.firedetection.biz.users.service;

public interface IntroduceService {

}
