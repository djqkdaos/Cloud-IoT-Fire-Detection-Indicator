package org.firedetection.biz.board.service;

public interface ReviewBoardService {

}
