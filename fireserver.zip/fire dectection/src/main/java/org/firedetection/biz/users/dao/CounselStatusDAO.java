package org.firedetection.biz.users.dao;

public interface CounselStatusDAO {

}
