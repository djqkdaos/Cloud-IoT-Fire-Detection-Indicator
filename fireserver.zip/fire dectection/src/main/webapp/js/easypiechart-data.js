$(function() {
    $('#easypiechart-teal').easyPieChart({
        scaleColor: false,
        barColor: '#1ebfae'
    });
});

$(function() {
    $('#easypiechart-orange').easyPieChart({
        scaleColor: false,
        barColor: '#ffb53e'
    });
});

$(function() {
    $('#easypiechart-red1').easyPieChart({
        scaleColor: false,
        barColor: '#f9243f'
    });
});

$(function() {
    $('#easypiechart-red2').easyPieChart({
        scaleColor: false,
        barColor: '#f9243f'
    });
});
$(function() {
    $('#easypiechart-red3').easyPieChart({
        scaleColor: false,
        barColor: '#f9243f'
    });
});
$(function() {
   $('#easypiechart-blue').easyPieChart({
       scaleColor: false,
       barColor: '#f9243f'
   });
});

$('#calendar').datepicker({
	});
